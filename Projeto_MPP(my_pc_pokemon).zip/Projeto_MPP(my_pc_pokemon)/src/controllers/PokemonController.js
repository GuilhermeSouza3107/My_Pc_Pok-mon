const connection = require('../config/database');

class PokemonController {
    async listar(req, res) {
        const [rows] = await connection.query("SELECT * FROM pokemons");
        res.json(rows);
    }

    async criar(req, res) {
        const { id_box, nome, tipo, level_pokemon, hp, atk, def, sp_atk, sp_def, speed } = req.body;
        try {
            const [result] = await connection.query(
                "INSERT INTO pokemons (id_box, nome, tipo, level_pokemon, hp, atk, def, sp_atk, sp_def, speed) VALUES (?,?,?,?,?,?,?,?,?,?)",
                [id_box, nome, tipo, level_pokemon, hp, atk, def, sp_atk, sp_def, speed]
            );
            res.status(201).json({ id: result.insertId, ...req.body });
        } catch (err) { res.status(500).json({ erro: err.message }); }
    }

    async atualizar(req, res) {
        const { id } = req.params;
        const { nome, level_pokemon } = req.body; 
        await connection.query("UPDATE pokemons SET nome=?, level_pokemon=? WHERE id=?", [nome, level_pokemon, id]);
        res.json({ mensagem: "Pokémon atualizado" });
    }

    async deletar(req, res) {
        await connection.query("DELETE FROM pokemons WHERE id=?", [req.params.id]);
        res.status(204).send();
    }
}
module.exports = new PokemonController();