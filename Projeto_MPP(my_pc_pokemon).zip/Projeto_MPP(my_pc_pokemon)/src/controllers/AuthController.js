const connection = require('../config/database');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

class AuthController {
    async registrar(req, res) {
        const { username, senha } = req.body;
        const hash = await bcrypt.hash(senha, 10);
        try {
            await connection.query("INSERT INTO usuarios (username, senha) VALUES (?, ?)", [username, hash]);
            res.status(201).json({ mensagem: "Usuário criado!" });
        } catch (err) { res.status(500).json({ erro: err.message }); }
    }

    async login(req, res) {
        const { username, senha } = req.body;
        const [rows] = await connection.query("SELECT * FROM usuarios WHERE username = ?", [username]);
        
        if (rows.length === 0 || !(await bcrypt.compare(senha, rows[0].senha))) {
            return res.status(401).json({ erro: "Credenciais inválidas" });
        }

        const token = jwt.sign({ id: rows[0].id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    }
}
module.exports = new AuthController();